<?php
$names = $_POST["nama"];
echo "<p>telah diisikan .$names.<p>";
$tempatlahir = $_POST["tempatlahir"];
echo "<p>telah diisikan .$tempatlahir.<p>";
$tanggallahir = $_POST["tanggallahir"];
echo "<p>telah diisikan .$tanggallahir.<p>";
$alamatrumah = $_POST["alamatrumah"];
echo "<p>telah diisikan .$alamatrumah.<p>";
$jeniskelamin = $_POST["jeniskelamin"];
echo "<p>telah diisikan .$jeniskelamin.<p>";
$asalsekolah = $_POST["asalsekolah"];
echo "<p>telah diisikan .$asalsekolah.<p>";
$nilaiuan = $_POST["nilaiuan"];
echo "<p>telah diisikan .$nilaiuan.<p>";
?>